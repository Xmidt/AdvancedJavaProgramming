import java.util.ArrayList;
import java.util.List;

public class Eating {

	static <U extends Edible, T extends U> void  foo(List<? extends T> x, T y) {
		
	}
	
	static <T extends Animal> T bar() {
		return null;
	}
	
	static void addADog(List<? super Dog> list, Dog dog) {
		list.add(dog);
	}
	
	static <S> S head(List<S> list) {
		return list.get(0);
	}
	
	static <S, T extends S> List<S> cons(T x, List<S> list) {
		list.add(x);
		return list;
	}
	
	public static void main(String[] args) throws InterruptedException {
		List<Dog> es = new ArrayList<Dog>();
		es.add(new Dog());
		Dog d = head(cons(head(es), es));
		synchronized (d) {			
			d.wait(100000);
		}
	}
}
