
public interface Hairy {
	void groom();
}
