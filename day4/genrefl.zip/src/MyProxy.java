import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class MyProxy implements InvocationHandler {
	
	public static void main(String[] args) {
		InvocationHandler handler = new MyProxy();
		Edible proxy = (Edible) Proxy.newProxyInstance(
				Edible.class.getClassLoader(), new Class[] { Edible.class },
				handler);
		proxy.eat();proxy.eat();proxy.eat();
	}

	@Override
	public Object invoke(Object arg0, Method arg1, Object[] arg2)
			throws Throwable {
		System.out.println(arg1);
		
		
		return null;
	}
}
