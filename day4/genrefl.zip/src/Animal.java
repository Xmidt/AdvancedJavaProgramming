
public class Animal implements Edible {

	@Override
	public void eat() {
	}
	
}
