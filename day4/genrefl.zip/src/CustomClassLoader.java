import java.io.FileInputStream;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;

public class CustomClassLoader extends ClassLoader {

 String repoLocation = "/tmp/";

 public CustomClassLoader() { }
 
 public CustomClassLoader(ClassLoader parent) {
  super(parent);
 }
 
 @SuppressWarnings({ "unchecked", "rawtypes" })
@Override
 protected Class<?> findClass(final String name)
   throws ClassNotFoundException {

  AccessControlContext acc = AccessController.getContext();

  try {
   return (Class)AccessController.doPrivileged(
     new PrivilegedExceptionAction() {
      public Object run() throws ClassNotFoundException {

       FileInputStream fi = null;
       try {

        String path = name.replace('.', '/');
        fi = new FileInputStream(repoLocation + path
          + ".class");
        byte[] classBytes = new byte[fi.available()];
        fi.read(classBytes);
        fi.close();
        return defineClass(name, classBytes, 0,
          classBytes.length);
       }catch(Exception e )
       {
        throw new ClassNotFoundException(name);
       }
      }
     }, acc);
  } catch (java.security.PrivilegedActionException pae) {
   return super.findClass(name);
  }
 }
 
 public static void main(String[] args) throws Exception{
  ClassLoader cls= new CustomClassLoader(ClassLoader.getSystemClassLoader());
  Class<?> stringClass=cls.loadClass("ABC");
  stringClass.newInstance();
  
  ClassDeclarationSpy.cl = cls;
  ClassDeclarationSpy.main("ABC");
 }
}