
public class Pair<A,B> {

	A first;
	B second;

	
	public Pair(A first, B second) {
		super();
		this.first = first;
		this.second = second;
	}
}