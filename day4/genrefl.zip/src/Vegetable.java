
public class Vegetable implements Edible {

	@Override
	public void eat() {
		
	}

}
