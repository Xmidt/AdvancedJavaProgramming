
public class Dog extends Animal implements Hairy {

	@Override
	public void groom() {
		
	}
	
	

}
