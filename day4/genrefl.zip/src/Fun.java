import java.lang.reflect.Type;



public interface Fun<A,B> {
	
	B apply(A x);
	
	static class Funs {
		public static void main(String[] args) {
			Fun<String, Dog> f = null;
			Fun<Animal, Vegetable> g = null;
			
			
			//Fun<String, Vegetable> h = Funs.<String,Dog,Vegetable>compose(f, g);
			
			Dog x = f.apply("Pluto");
			g.apply(x);
			
			Type t = String.class;
		}
	}
}
