
public interface Edible {
	void eat();
}
