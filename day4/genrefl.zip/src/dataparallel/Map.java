package dataparallel;

import java.util.List;

public interface Map {
	
	<T> void map(Mutation<T> m, List<T> xs);
	
	static class MapSeq implements Map {

		@Override
		public <S> void map(Mutation<S> m, List<S> xs) {
			for (S e : xs) {
				m.mutate(e);
			}
		}
	}	
}
