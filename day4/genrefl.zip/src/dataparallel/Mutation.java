package dataparallel;

import java.util.Collections;
import java.util.List;

public interface Mutation<T> {
	
	void mutate(T e);
	
	static class LowerCaseName implements Mutation<Employee> {

		@Override
		public void mutate(Employee e) {
			e.name = e.name.toLowerCase();
		}
	}
	
	static class ReverseList<S> implements Mutation<List<S>> {

		@Override
		public void mutate(List<S> e) {
			Collections.reverse(e);
		}

		
	}
}
