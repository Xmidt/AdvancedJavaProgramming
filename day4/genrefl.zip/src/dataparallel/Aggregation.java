package dataparallel;

import java.util.List;

public interface Aggregation {
	
	<E, N> N aggregate(Combination<E, N> c, List<E> xs);
	
	
	static class AggSeq implements Aggregation {

		@Override
		public <E, N> N aggregate(Combination<E, N> c, List<E> xs) {
			N x = c.neutral();
			for (E e : xs) {
				x = c.combine(x, c.elementToNumber(e));
			}
			return x;
		}
		
	}
}
