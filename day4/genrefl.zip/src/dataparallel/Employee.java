package dataparallel;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	int age, salary;
	String name;
	
	public static List<Employee> getList() {
		List<Employee> xs = new ArrayList<>();
		xs.add(new Employee());
		xs.add(new Employee());
		xs.add(new Employee());
		xs.get(0).name = "John Doe";
		xs.get(1).name = "Frederik";
		xs.get(2).name = "Vivek";
		xs.get(0).age = 40;
		xs.get(1).age = 25;
		xs.get(2).age = 25;
		xs.get(0).salary = 4000;
		xs.get(1).salary = 1000;
		xs.get(2).salary = 2000;
		return xs;
	}
	
	@Override
	public String toString() {
		return name + "[" + age + " years, " + salary + "$]";
	}
}
