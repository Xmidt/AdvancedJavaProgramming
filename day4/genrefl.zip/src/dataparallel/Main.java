package dataparallel;

import java.util.List;

import dataparallel.Aggregation.AggSeq;
import dataparallel.Map.MapSeq;
import dataparallel.Mutation.LowerCaseName;

public class Main {
	
	public static void main(String[] args) {
		System.out.println("MAP lower case name");
		System.out.println();
		
		List<Employee> employees = Employee.getList();
		
		
		System.out.println("Before: " + employees);
		
		
		MapSeq map = new MapSeq();
		map.<Employee>map(new Mutation.LowerCaseName(), employees);
		
		Mutation<List<String>> m = new Mutation.ReverseList<String>();
		
		
		System.out.println("After: " + employees);
		System.out.println();
		
		System.out.println("AGGREGATION minimum age");
		System.out.println();
		AggSeq ag = new AggSeq();
		System.out.println("Min age: " + ag.aggregate(new Combination.MinAge(), employees));
	}

}
