package dataparallel;

public interface Combination<E, N> {

	N neutral();
	N combine(N x, N y);
	N elementToNumber(E e);
	
	static class MinAge implements Combination<Employee, Integer> {

		@Override
		public Integer neutral() {
			return Integer.MAX_VALUE;
		}

		@Override
		public Integer combine(Integer x, Integer y) {
			return Math.min(x, y);
		}

		@Override
		public Integer elementToNumber(Employee e) {
			return e.age;
		}
		
	}
}
