
public class Box<T> {
	T x;
	T get() { return x;}
	void set(T x) { this.x = x; }
	
	public static void main(String[] args) {
		Box<? extends Animal> b1 = null;
		Box<?> b2 = b1;
	}
}
