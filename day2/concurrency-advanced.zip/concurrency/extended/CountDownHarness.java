package concurrency.extended;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CountDownHarness {
	static int NUMBER_THREADS = 10;

	public static void main(String[] args) {
		SimpleCountdown task = new SimpleCountdown();
		ExecutorService exec = Executors.newCachedThreadPool();
		for (int i = 0; i < NUMBER_THREADS; i++) {
			//task = new SimpleCountdown();
			exec.submit(task);
		}
		exec.shutdown();
		System.out.println("Hello from Main Harness");

	}

}
