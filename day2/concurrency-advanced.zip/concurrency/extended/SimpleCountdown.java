package concurrency.extended;


public class SimpleCountdown implements Runnable {
	private int counter = 5;

	public void run() {
		while (this.counter-- > 0) {
			System.out.println("Hello " + counter + " from thread "+Thread.currentThread().getId());
			try {
				Thread.sleep(100);
				Thread.yield();
			} catch (InterruptedException ex) {
				System.out.println("Thread "+Thread.currentThread().getId()+ " got interrupted, exiting");
				return;
			} finally {
			}
		}
	}


}
