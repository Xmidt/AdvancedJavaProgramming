package concurrency.extended;

class SimpleNamePrinter {
	private String myName;
	private SimpleNamePrinter otherPrinter;
	
	public synchronized void setMyName(String myName) {
		this.myName = myName;
	}

	public synchronized void setRemotePrinter(SimpleNamePrinter otherPrinter) {
		this.otherPrinter = otherPrinter;
	}

	public synchronized void printNames() {
		this.printName();
		otherPrinter.printName();
	}
	
	public synchronized void printName() {
		System.out.println(myName);
	}

}
