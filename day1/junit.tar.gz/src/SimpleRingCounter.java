
public class SimpleRingCounter implements RingCounter {

	private int x = 1;
	
	@Override
	public int get() {
		// TODO Auto-generated method stub
		return x;
	}

	@Override
	public void inc(int n) throws IllegalArgumentException {

		if(n >= 0) {
			x += n;
		}
		else {
			throw new IllegalArgumentException();
		}
		while(x > 16) {
			x -= 16;
		}
	}

}
