import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */

/**
 * @author fmma
 *
 */
public class RingCounterTest {


	RingCounter rc = new SimpleRingCounter();
	
	/**
	 * Test method for {@link RingCounter#get()}.
	 */
	@Test
	public void testGet() {
		assertEquals(1, rc.get());
	}

	/**
	 * Test method for {@link RingCounter#inc(int)}.
	 */
	@Test
	public void testInc() {
		rc.inc(0);
		assertEquals(1, rc.get());
		rc.inc(1);
		assertEquals(2, rc.get());
		rc.inc(3);
		assertEquals(5, rc.get());
		rc.inc(12);
		assertEquals(1, rc.get());
		rc.inc(32);
		assertEquals(1, rc.get());
		try {			
			rc.inc(-5);
			fail("Should have ...");
		} catch (Exception e) {
		}
	}

}
